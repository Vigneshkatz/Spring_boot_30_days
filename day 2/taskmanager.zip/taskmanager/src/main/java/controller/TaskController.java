package controller;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import model.Task;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import services.TaskService;

import java.util.List;

@RestController
@RequestMapping(value={"/api/v1"})
@CrossOrigin("*")
@AllArgsConstructor
@NoArgsConstructor
public class TaskController {
    private TaskService taskService;

    @GetMapping("/task")
    public List<Task> getTask(){
        return taskService.getTasks();
    }

}
