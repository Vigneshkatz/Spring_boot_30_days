package services;

import lombok.AllArgsConstructor;
import model.Task;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import repository.TaskRepository;

import java.util.List;

@Service
@AllArgsConstructor

public class TaskService {

    private TaskRepository taskRepository;

    @Transactional(readOnly = true)
    public List<Task> getTasks(){
        return taskRepository.findAll();
    }
}
